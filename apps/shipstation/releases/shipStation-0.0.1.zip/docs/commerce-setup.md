# Setting up a Commerce Instance

This runs down our experience setting up [the sandbox](https://stage-sandbox.m2cloud.blueacorn.net) that we will build the solution for.

## Setup Procedure

```bash



```